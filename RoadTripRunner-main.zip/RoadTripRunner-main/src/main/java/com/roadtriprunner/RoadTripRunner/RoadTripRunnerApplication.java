package com.roadtriprunner.RoadTripRunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoadTripRunnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoadTripRunnerApplication.class, args);
	}

}
