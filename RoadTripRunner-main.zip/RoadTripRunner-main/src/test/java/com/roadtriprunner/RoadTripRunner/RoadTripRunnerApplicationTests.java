package com.roadtriprunner.RoadTripRunner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadTripRunnerApplicationTests {

	@Test
	void contextLoads() {
	}

}
